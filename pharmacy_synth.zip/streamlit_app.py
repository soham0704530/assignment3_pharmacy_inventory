
import streamlit as st
import pandas as pd
from datetime import datetime, timedelta

st.set_page_config(page_title="Pharmacy Inventory Alerts", layout="wide")

@st.cache_data
def load_data(path):
    meds = pd.read_csv(path + "/medicines.csv")
    suppliers = pd.read_csv(path + "/suppliers.csv")
    purchase = pd.read_csv(path + "/purchase_stock.csv", parse_dates=['purchase_date','expiry_date'])
    sales = pd.read_csv(path + "/pharmacy_sale.csv", parse_dates=['sale_datetime'])
    sale_items = pd.read_csv(path + "/pharmacy_sale_item.csv")
    return meds, suppliers, purchase, sales, sale_items

DATA_PATH = "/mnt/data/pharmacy_synth"
meds, suppliers, purchase, sales, sale_items = load_data(DATA_PATH)

st.title("Pharmacy Inventory & Expiry Alerts (Synthetic Data)")

col1, col2 = st.columns([2,1])
with col1:
    st.subheader("Summary Metrics")
    total_meds = meds.shape[0]
    total_batches = purchase.shape[0]
    total_sales = sales.shape[0]
    total_units_sold = sale_items['sold_quantity'].sum()
    st.metric("Distinct Medicines", total_meds)
    st.metric("Batches Purchased", total_batches)
    st.metric("Total Sales Txns", total_sales)
    st.metric("Units Sold (sum)", int(total_units_sold))

with col2:
    st.subheader("Filters")
    days_to_expiry = st.number_input("Days to consider as 'near expiry'", min_value=7, max_value=365, value=60)
    min_remaining_qty = st.number_input("Min remaining qty to alert", min_value=1, max_value=1000, value=1)

# Compute remaining qty per batch
sold_by_batch = sale_items.groupby(['batch_no','medicine_id'])['sold_quantity'].sum().reset_index()
purchase_with_sold = purchase.merge(sold_by_batch, on=['batch_no','medicine_id'], how='left')
purchase_with_sold['sold_quantity'] = purchase_with_sold['sold_quantity'].fillna(0).astype(int)
purchase_with_sold['remaining_qty'] = purchase_with_sold['purchase_quantity'] - purchase_with_sold['sold_quantity']
purchase_with_sold['days_to_expiry'] = (purchase_with_sold['expiry_date'] - pd.Timestamp.now()).dt.days

near_expiry = purchase_with_sold[
    (purchase_with_sold['days_to_expiry'] <= days_to_expiry) &
    (purchase_with_sold['remaining_qty'] >= min_remaining_qty)
].sort_values(['days_to_expiry'])

st.subheader(f"Near-expiry batches (<= {days_to_expiry} days)")
st.dataframe(near_expiry[['batch_no','medicine_id','purchase_quantity','sold_quantity','remaining_qty','expiry_date','days_to_expiry']].head(200))

st.subheader("Top medicines by units sold")
top_meds = sale_items.groupby('medicine_id')['sold_quantity'].sum().reset_index().sort_values('sold_quantity', ascending=False)
top_meds = top_meds.merge(meds[['medicine_id','name']], on='medicine_id', how='left')
st.dataframe(top_meds.head(50))

st.subheader("Low stock medicines (closing stock <= threshold)")
# compute closing stock per medicine
purchased_by_med = purchase.groupby('medicine_id')['purchase_quantity'].sum().reset_index()
sold_by_med = sale_items.groupby('medicine_id')['sold_quantity'].sum().reset_index()
stock_med = purchased_by_med.merge(sold_by_med, on='medicine_id', how='left').fillna(0)
stock_med['closing_stock'] = stock_med['purchase_quantity'] - stock_med['sold_quantity']
stock_med = stock_med.merge(meds[['medicine_id','name']], on='medicine_id', how='left')
threshold = st.number_input("Low stock threshold per medicine", min_value=0, max_value=1000, value=10)
low_stock = stock_med[stock_med['closing_stock'] <= threshold].sort_values('closing_stock')
st.dataframe(low_stock.head(200))

st.markdown("---")
st.write("Notes: This is a synthetic demo. For production, connect to the live DB and use parametrized queries, auth, and caching.")
